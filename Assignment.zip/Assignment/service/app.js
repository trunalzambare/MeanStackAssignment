const express =  require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const mongoose = require('mongoose')
const app = express();
const db = require("./config/config");
const userRoute = require('./app/routes/user.route');
mongoose.Promise = global.Promise;
mongoose.connect(db.url, { useNewUrlParser: true, useUnifiedTopology: true }).then(
  () => {console.log('Database is connected') },
  err => { console.log('Can not connect to the database'+ err)}
);

app.use(bodyParser.json());
app.use(cors());
app.use('/user', userRoute);
const port = process.env.PORT || 1337;

const server = app.listen(port, function(){
 console.log('Listening on port ' + port);
});