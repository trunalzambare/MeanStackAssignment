const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let User = new Schema({
    firstName: {
      type: String
    },
    lastName: {
      type: String
    },
    email: {
      type: String
    },
    phoneNumber: {
        type: Number
    },
    profileImage: {
        type: String
      }
  },{
      collection: 'user'
  });
  
  module.exports = mongoose.model('User', User);