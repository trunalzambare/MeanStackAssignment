const express = require('express');
const app = express();
const userRoutes = express.Router();
let User = require('../models/User');

userRoutes.route('/create').post(function (req, res) {
    let user = new User(req.body);
    console.log(user)
    user.save()
      .then(user => {
        res.status(200).json({'user': 'user added successfully'});
      })
      .catch(err => {
      res.status(400).send("failed to create user");
      });
});
  
userRoutes.route('/').get(function (req, res) {
    User.find(function (err, users){
        if(err){
        console.log(err);
        }
        else {
        res.json(users);
        }
    });
});

userRoutes.route('/getUserDetails/:id').get(function (req, res) {
    let id = req.params.id;
    User.findById(id, function (err, user){
        res.json(user);
    });
  });

userRoutes.route('/update/:id').post(function (req, res) {
    console.log(req.params)
    User.findById(req.params.id, function(err, user) {
    if (!user)
    res.status(400).send("User not found");
    else {
        console.log(req.body)
        user.firstName = req.body.firstName;
        user.lastName = req.body.lastName;
        user.email = req.body.email;
        user.phoneNumber = req.body.phoneNumber;
        user.profileImage = req.body.profileImage;

        user.save().then(user => {
          res.json('User updated successfully');
      })
      .catch(err => {
            res.status(400).send("failed to update user");
      });
    }
  });
});

userRoutes.route('/delete/:id').get(function (req, res) {
    User.findByIdAndRemove({_id: req.params.id}, function(err, user){
        if(err) res.json(err);
        else res.json('User deleted successfully');
    });
});

module.exports = userRoutes;