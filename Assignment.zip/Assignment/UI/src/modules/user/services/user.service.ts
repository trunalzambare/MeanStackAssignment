import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";

const baseUrl = "http://localhost:1337/user";

@Injectable({
  providedIn: "root",
})
export class UserService {
  constructor(private http: HttpClient) {}

  getUsers() {
    return this.http.get(baseUrl);
  }

  getUserDetails(id) {
    return this.http.get(baseUrl + "/getUserDetails/" + id);
  }

  createUser(data) {
    return this.http.post(baseUrl + "/create", data);
  }

  updateUser(data, id) {
    return this.http.post(baseUrl + "/update/" + id, data);
  }

  deleteUser(id) {
    return this.http.get(baseUrl + "/delete/" + id);
  }
}
