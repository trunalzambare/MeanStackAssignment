import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { UserService } from "../services/user.service";
@Component({
  selector: "app-create-user",
  templateUrl: "./create-user.component.html",
  styleUrls: ["./create-user.component.scss"],
})
export class CreateUserComponent implements OnInit {
  userForm: FormGroup;
  constructor(
    private userService: UserService,
    public fb: FormBuilder,
    private router: Router
  ) {}

  ngOnInit() {
    this.userForm = this.fb.group({
      firstName: ["", Validators.required],
      lastName: ["", Validators.required],
      email: ["", Validators.required],
      phoneNumber: ["", [Validators.pattern("[0-9]*"), Validators.required]],
      profileImage: [""],
    });
  }

  createUser() {
    console.log(this.userForm.value);
    this.userService.createUser(this.userForm.value).subscribe((res) => {
      console.log("User created!");
      this.router.navigateByUrl("/list-users");
    });
  }
}
