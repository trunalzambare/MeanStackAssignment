import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { UserService } from "../services/user.service";

@Component({
  selector: "app-update-user",
  templateUrl: "./update-user.component.html",
  styleUrls: ["./update-user.component.scss"],
})
export class UpdateUserComponent implements OnInit {
  userForm: FormGroup;
  user: any;
  constructor(
    private userService: UserService,
    public fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  async ngOnInit() {
    this.userForm = this.fb.group({
      firstName: ["", Validators.required],
      lastName: ["", Validators.required],
      email: ["", Validators.required],
      phoneNumber: ["", Validators.required],
      profileImage: [""],
    });
    await this.getUserDetails();
  }

  getUserDetails() {
    this.route.params.subscribe((params) => {
      this.userService.getUserDetails(params["id"]).subscribe((res) => {
        this.user = res;
        console.log(this.user);
      });
    });
  }

  updateUser() {
    this.route.params.subscribe((params) => {
      this.userService
        .updateUser(this.userForm.value, params["id"])
        .subscribe((response) => {
          this.router.navigate(["/"]);
        });
    });
  }
}
