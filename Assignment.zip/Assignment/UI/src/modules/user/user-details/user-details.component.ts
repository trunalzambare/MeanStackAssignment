import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { UserService } from "../services/user.service";

@Component({
  selector: "app-user-details",
  templateUrl: "./user-details.component.html",
  styleUrls: ["./user-details.component.scss"],
})
export class UserDetailsComponent implements OnInit {
  user: any;
  constructor(
    private router: Router,
    private userService: UserService,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.getUserDetails();
  }

  getUserDetails() {
    this.route.params.subscribe((params) => {
      this.userService.getUserDetails(params["id"]).subscribe((res) => {
        this.user = res;
        console.log(this.user);
      });
    });
  }
}
